package bg.uni.sofia.fmi.mjt.dungeon.treasure;
import bg.uni.sofia.fmi.mjt.dungeon.actor.*;
public interface Treasure {
	String collect(Hero h);
}
